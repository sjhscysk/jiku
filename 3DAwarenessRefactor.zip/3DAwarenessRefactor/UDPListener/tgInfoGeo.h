﻿
#pragma once
#pragma pack(1)
typedef struct _tgInfoGeo
{
    int tgID;//目标编号  显示目标编号
    int classID;//目标种类
    double lon;
    double lat;
    double alt;
    double roll;
    double pitch;
    double yaw;
    double pX;
    double pY;
    double pZ;
    int srcID;
    int confidence;
}TgInfoGeo;


typedef struct tgGeos
{
    TgInfoGeo tgs[10];//目标列表
    int tgCount;     //目标数量
}TgGeos;
#pragma pack()
