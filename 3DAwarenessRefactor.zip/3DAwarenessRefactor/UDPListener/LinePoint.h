﻿#include <QQueue>
//#include <QPoint>
namespace Esri
{
namespace ArcGISRuntime
{
class Scene;
class SceneQuickView;
//created by 1103
class GlobeCameraController;
class Graphic;
class GraphicsOverlay;
class MapQuickView;
class ModelSceneSymbol;
class OrbitGeoElementCameraController;
class SceneQuickView;
class SimpleMarkerSymbol;
class GlobeCameraController;
//created by zh draw the line
class SimpleLineSymbol;
class SimpleMarkerSymbol;
class Point;
}
}
#pragma once
#pragma pack(1)


namespace LP {

typedef struct
{
    //接受航线的10个点
    short airID;     //飞机的ID

    //QQueue m_TrackQueue2;
    QQueue<Esri::ArcGISRuntime::Point> m_lineQueue;

}LinePoint;

}
#pragma pack()
