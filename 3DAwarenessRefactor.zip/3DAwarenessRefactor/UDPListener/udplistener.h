﻿#ifndef UDPLISTENER_H
#define UDPLISTENER_H

#include "udplistener_global.h"
#include <QUdpSocket>
#include <QbImgPara.h>
#include <tgInfoGeo.h>

//created by 1114
#include <LinePoint.h>


#include <QObject>
class UDPLISTENERSHARED_EXPORT UDPListener :public QObject
{
    Q_OBJECT
public:
    explicit UDPListener(QObject* parent = nullptr);
public:
signals:
    void UAVInfoGot(const QB::QbImgPara * info);
    void TargetInfoGot(const tgGeos * info);

    //created by 1114
    void LinePointGot(const LP::LinePoint *info);

private slots:
    void processPendingDatagrams();
private:
    QUdpSocket udpSocket4;

    QHostAddress groupAddress4;


};

#endif // UDPLISTENER_H
