﻿#include "udplistener.h"
#include <QDebug>
#include <QbImgPara.h>
#include <tgInfoGeo.h>
#include <LinePoint.h>

UDPListener::UDPListener(QObject *parent):QObject (parent)
  ,groupAddress4(QStringLiteral("224.5.4.5"))
{
    //有飞机信号进入，开始监听
    qDebug()<<QString::fromLocal8Bit("有飞机信号进入，开始监听")<<endl;
    udpSocket4.bind(QHostAddress::AnyIPv4, 21845, QUdpSocket::ShareAddress);
    udpSocket4.joinMulticastGroup(groupAddress4);
    connect(&udpSocket4, SIGNAL(readyRead()),
            this, SLOT(processPendingDatagrams()));


}

void UDPListener::processPendingDatagrams()
{
    QByteArray datagram;

    // using QUdpSocket::readDatagram (API since Qt 4)
    while (udpSocket4.hasPendingDatagrams()) {
        datagram.resize(int(udpSocket4.pendingDatagramSize()));
        udpSocket4.readDatagram(datagram.data(), datagram.size());
        qDebug()<<"有数据进入"<<endl;
        //created by 1114
        LP::LinePoint *_LinePointInfo;

        QB::QbImgPara *_planeInfo;
        tgGeos * _targetInfo;
        switch (datagram.size()) {
        case sizeof(QB::QbImgPara):
            _planeInfo  = (QB::QbImgPara *)datagram.constData();
            emit UAVInfoGot(_planeInfo);
            break;
        case sizeof(tgGeos):
            _targetInfo = (tgGeos *)datagram.constData();
            emit TargetInfoGot(_targetInfo);
            break;

        //created by 1114
        case sizeof(LP::LinePoint):
            _LinePointInfo=(LP::LinePoint *)datagram.constData();
            emit LinePointGot(_LinePointInfo);

        default:
            break;

        }
    }
}

