﻿#pragma once
#pragma pack(1)
namespace QB {
typedef struct
{

    //飞机参数
    short     airType;     //飞机类型    08->固定翼  05->悬翼
    short     airID;        //飞机ID
    double      lon;         //飞机经度，°为单位
    double      lat;         //飞机纬度，°为单位
    float      alt;      //飞机高度，m为单位
    float      roll;        //飞机滚转，°为单位
    float      pitch;       //飞机俯仰，°为单位
    float      yaw;         //飞机航向，°为单位
    float      v_ground; //地速
    float      v_sky;//天速
    //载荷参数
    short    loadType;    //载荷类型
    float      eoroll;          //载荷翻滚角，°为单位
    float      eopitch;        //载荷高低角，°为单位
    float      eoaz;           //载荷方位角，°为单位,水平为0°
    float      laser;          //激光测距值，单位为m
    double      focus;          //图像的焦距值，以m为单位
    //图像参数
    short     imgType;//图像类型
    short     iFrameNum;//帧序号
    //图像的幅宽，以像素单位
    short     imgWidth;
    short     imgHeight;
    short     imgChannel;
    short BiasX;//像素X坐标(脱靶量)
    short BiasY;//像素Y坐标(脱靶量)
    //面阵大小,单位米
    double sensorWidth;
    double sensorHeight;
    //图像的像元尺寸，以m为单位
    double  xSize;
    double  ySize;
    //时间参数
    short    Year;               //UTC年
    short    Month;              //UTC月
    short    Day;                //UTC日
    short    Hour;//时
    short    Minute;//分
    short    Second;//秒
    unsigned int Utc;            //天秒（单位ms）
    //地面/地球信息
    float gdHeight;//地面高度，以m为单位
    short   ellipseType;    //椭球体类型：1为BJ54椭球;2为西安80；3为WGS84椭球
    //保留字节数，用于扩展
    unsigned char reserved[100];
}QbImgPara;
}
#pragma pack()
