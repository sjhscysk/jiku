﻿#ifndef CAMERAFRUSTUM_H
#define CAMERAFRUSTUM_H

#include <QObject>
#include <udplistener.h>
#include <Polygon.h>
#include <SceneQuickView.h>

class CameraFrustum : public QObject
{
    Q_OBJECT
public:
    explicit CameraFrustum(QObject *parent = nullptr,Esri::ArcGISRuntime::SceneQuickView * sceneview = nullptr);
    void drawFrustum(const QB::QbImgPara * info);
private:
    void updateFrustum(const QB::QbImgPara * info);

    void addFrustum(const QB::QbImgPara * info);

    std::vector<Esri::ArcGISRuntime::Polygon> makeFrustumPolygon(const QB::QbImgPara * info);
public slots:
private:
    int m_maxCountFrustum_;
    int m_countFrustum_;
    Esri::ArcGISRuntime::SceneQuickView * m_sceneView_;
    QMap<int,size_t> m_UAVID_PolygonPairs_;
    std::vector<std::vector<Esri::ArcGISRuntime::Graphic*>> m_frustumGraphics_;
};

#endif // CAMERAFRUSTUM_H
