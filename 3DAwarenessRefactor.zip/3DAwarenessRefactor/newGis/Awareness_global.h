﻿#ifndef AWARENESS_GLOBAL_H
#define AWARENESS_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(AWARENESS_LIBRARY)
#  define AWARENESS_EXPORT Q_DECL_EXPORT
#else
#  define AWARENESS_EXPORT Q_DECL_IMPORT
#endif

#endif // AWARENESS_GLOBAL_H
