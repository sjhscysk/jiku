﻿#ifndef UAVTESTLABEL_H
#define UAVTESTLABEL_H

#include <QObject>
#include <udplistener.h>
#include <SceneQuickView.h>
#include <QQueue>
#include"PolylineBuilder.h"


class UAVTextLabel : public QObject
{
    Q_OBJECT
public:
    explicit UAVTextLabel(QObject *parent = nullptr,Esri::ArcGISRuntime::SceneQuickView * sceneview = nullptr);
    void drawTextLabel(const QB::QbImgPara * info);


private:
    void updateTextLabel(const QB::QbImgPara * info);

    void addTextLabel(const QB::QbImgPara * info);



    Esri::ArcGISRuntime::Geometry createPoint(const QB::QbImgPara *info);

    Esri::ArcGISRuntime::Geometry createPolyline(const QB::QbImgPara *info);

private:

    Esri::ArcGISRuntime::SceneQuickView * m_sceneView_;

    //TextLabel的写法
    int m_maxCountLabel_;
    int m_countLabel_;
    QMap<int,size_t> m_UAVID_LabelPairs_;
    std::vector<Esri::ArcGISRuntime::Graphic*> m_textLabelGraphics_;


    //Point的写法
    int m_maxCountPoint_;
    int m_countPoint_;
    QMap<int,size_t> m_UAVID_PointPairs_;
    std::vector<Esri::ArcGISRuntime::Graphic*> m_PointGraphics_;

    //Line的写法
    int m_maxCountLine_;
    int m_countLine_;
    QMap<int,size_t> m_UAVID_Lines_;
    std::vector<Esri::ArcGISRuntime::GraphicsOverlay*> m_LineGraphics_;

    Esri::ArcGISRuntime::PolylineBuilder polylineBuilder;

    //测试线条
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder1;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder2;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder0;

    //画出航迹
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder3;

    //Esri::ArcGISRuntime::PolylineBuilder polylineBuilder3;
    //Line的写法第二种

    //测试点成功
    int m_maxCountLine1_;
    int m_countLine1_;
    QMap<int,size_t> m_UAVID_Lines1_;
    std::vector<Esri::ArcGISRuntime::Graphic*> m_LineGraphics1_;

    std::vector<Esri::ArcGISRuntime::Point> m_PointCount;

    std::list<Esri::ArcGISRuntime::Point> m_PointList;

    //队列画出航迹的点
    QQueue<Esri::ArcGISRuntime::Point> m_PointQueue;
    QQueue<Esri::ArcGISRuntime::Point> m_PointQueue1;
    QQueue<Esri::ArcGISRuntime::Point> m_PointQueue2;

    //画出封边的点
    QQueue<Esri::ArcGISRuntime::Point> m_PointRoute;



    std::vector<Esri::ArcGISRuntime::Point> m_PointVector;
    std::list<Esri::ArcGISRuntime::Point>::iterator iter;




    //开始测试线条
    int m_maxCountLine2_;
    int m_countLine2_;
    QMap<int,size_t> m_UAVID_Lines2_;
    std::vector<Esri::ArcGISRuntime::Graphic*> m_LineGraphics2_;

    //Esri::ArcGISRuntime::GraphicsOverlay *m_graphicsOverlay=nullptr;
};

#endif // UAVTESTLABEL_H
