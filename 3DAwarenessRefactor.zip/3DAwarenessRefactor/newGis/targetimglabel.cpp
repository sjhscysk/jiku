﻿#include "targetimglabel.h"
#include <PictureMarkerSymbol.h>
#include <TextSymbol.h>
namespace  {

std::map<int ,QString> m_targetNameMap_;
void MakeTargetNameMap()
{

    m_targetNameMap_[0] = QStringLiteral(":/icons/babu.png");
    m_targetNameMap_[1] = QStringLiteral(":/icons/xiaoche.png");
    m_targetNameMap_[2] = QStringLiteral(":/icons/dache.png");
    m_targetNameMap_[3] = QStringLiteral(":/icons/renyuan.png");
    m_targetNameMap_[4] = QStringLiteral(":/icons/zhangpeng.png");
    m_targetNameMap_[5] = QStringLiteral(":/icons/zhihuibu.png");

}
}
using namespace Esri::ArcGISRuntime;
TargetImgLabel::TargetImgLabel(QObject *parent,Esri::ArcGISRuntime::SceneQuickView * sceneview ) : QObject(parent)
  ,m_sceneView_(sceneview)
{
    MakeTargetNameMap();
}

void TargetImgLabel::drawTargetImgLabel(const tgGeos *info)
{
    QString url = m_targetNameMap_[info->tgs[0].classID];
    int id =        info->tgs[0].tgID;
    double  lon=       info->tgs[0].lon;
    double lat =        info->tgs[0].lat;
    QImage _img(url);
    QString _text = QString::number(lon,10,6) + QString(",") + QString::number(lat,10,6);
    PictureMarkerSymbol * _symbol = new PictureMarkerSymbol(_img,this);
    TextSymbol * _textSymbol = new TextSymbol(_text,QColor(0,0,0,128),15,HorizontalAlignment::Center,VerticalAlignment::Middle,this);
    _symbol->setWidth(30);
    _symbol->setHeight(30);

    Graphic * _tempGraphics = new Graphic(Point(lon,lat,3,SpatialReference::wgs84()),_symbol,this);
    Graphic * _tempTextGraphic = new Graphic(Point(lon,lat,id+20,SpatialReference::wgs84()),_textSymbol,this);
    m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempGraphics);
    m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempTextGraphic);

}
