﻿
// Copyright 2019 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// You may freely redistribute and use this sample code, with or
// without modification, provided you include the original copyright
// notice and use restrictions.
//
// See the Sample code usage restrictions document for further information.
//

#include "NewGis.h"

#include "ArcGISTiledElevationSource.h"
#include "Basemap.h"
#include "Scene.h"
#include "SceneQuickView.h"

//created by 1103
#include "Raster.h"
#include "RasterLayer.h"
#include "RasterElevationSource.h"
#include <QDebug>
#include "Camera.h"
#include <GeometryEngine.h>
#include "SimpleMarkerSymbol.h"
#include "SimpleLineSymbol.h"
#include "Multipoint.h"
#include "ModelSceneSymbol.h"
#include "SimpleRenderer.h"
#include "OrbitGeoElementCameraController.h"

//created by 1104
#include <awareness.h>
#include <unmanneddevice.h>


#include <GlobeCameraController.h>
#include <QDir>
#include <QDebug>

#include <QUrl>


#include <QJsonDocument>
#include <QJsonParseError>
#include <QFile>
#include <QJsonObject>
#include <QJsonArray>

int showAirline=1;
int airCategory=0;


namespace  {
const QString HEADING = "heading";
const QString PITCH = "pitch";
const QString ROLL = "roll";
}



using namespace Esri::ArcGISRuntime;

NewGis::NewGis(QObject* parent /* = nullptr */):
    QObject(parent),
    m_scene(new Scene()),
    m_UAVTextLabel_(nullptr),
    m_UAVTrack_(nullptr),
    m_cameraFrustum_(nullptr),
    m_UAVGraphicsCount_(0),
    m_maxUAVGraphics_(12),
    m_myLon_(113.7),
    m_myLat_(34.02),
    m_myAlt_(100),
    m_camDistance_(10000),
    m_graphicsOverlay(new GraphicsOverlay(this)),
    m_graphicsOverlayFrustum(new GraphicsOverlay(this)),
    m_elevationMarker(new Graphic(Geometry(), new SimpleMarkerSymbol(SimpleMarkerSymbolStyle::X, QColor(255,0,0,100), 20, this), this))
{
    // create a new elevation source from Terrain3D rest service
    //ArcGISTiledElevationSource* elevationSource = new ArcGISTiledElevationSource(
                //QUrl("https://elevation3d.arcgis.com/arcgis/rest/services/WorldElevation3D/Terrain3D/ImageServer"), this);

    // add the elevation source to the scene to display elevation
    //m_scene->baseSurface()->elevationSources()->append(elevationSource);
    m_graphicsOverlay->setSceneProperties(LayerSceneProperties(SurfacePlacement::Relative));
    m_graphicsOverlayFrustum->setSceneProperties(LayerSceneProperties(SurfacePlacement::Relative));

    m_listener_ = new UDPListener(this);
    connect(m_listener_,&UDPListener::UAVInfoGot,this,&NewGis::receiveUAVInfo);

    connect(m_listener_,&UDPListener::TargetInfoGot,this,&NewGis::receiveTargetInfo);

    //created by 1117  接受画航线的信号
    connect(m_listener_,&UDPListener::LinePointGot,this,&NewGis::receiveUAVLineInfo);


    m_globeCamera_ = new GlobeCameraController(this);
}

NewGis::~NewGis()
{
}

SceneQuickView* NewGis::sceneView() const
{
    return m_sceneView;
}



// Set the view (created in QML)
void NewGis::setSceneView(SceneQuickView* sceneView)
{
    if (!sceneView || sceneView == m_sceneView)
    {
        return;
    }

    m_sceneView = sceneView;
    m_sceneView->setArcGISScene(m_scene);

    emit sceneViewChanged();

    //created by 1103
    connect(m_sceneView,&SceneQuickView::mouseClicked,this,&NewGis::displayElevation);

    // Set the marker to be invisible initially, will be flaggd visible when user interacts with scene for the first time, to visualise clicked position
    m_elevationMarker->setVisible(false);

    // Add the marker to the graphics overlay so it will be displayed. Graphics overlay is attached to the sceneView in ::setSceneView()
    m_graphicsOverlay->graphics()->append(m_elevationMarker);


    // Append the graphics overlays to the sceneview, so we can visualise elevation on click
    m_sceneView->graphicsOverlays()->append(m_graphicsOverlay);
    m_sceneView->graphicsOverlays()->append(m_graphicsOverlayFrustum);


    SimpleRenderer* renderer3D = new SimpleRenderer(this);
    RendererSceneProperties renderProperties = renderer3D->sceneProperties();
    renderProperties.setHeadingExpression(QString("[%1]").arg(HEADING));
    renderProperties.setPitchExpression(QString("[%1]").arg(PITCH));
    renderProperties.setRollExpression(QString("[%1]").arg(ROLL));
    renderer3D->setSceneProperties(renderProperties);
    m_graphicsOverlay->setRenderer(renderer3D);

    SimpleRenderer* renderer3DFrustum = new SimpleRenderer(this);
    RendererSceneProperties renderPropertiesFrustum = renderer3DFrustum->sceneProperties();
    renderPropertiesFrustum.setHeadingExpression(QString("[%1]").arg(HEADING));
    renderPropertiesFrustum.setPitchExpression(QString("[%1]").arg(PITCH));
    renderer3DFrustum->setSceneProperties(renderPropertiesFrustum);
    m_graphicsOverlayFrustum->setRenderer(renderer3DFrustum);

    //created by 1104
    initUAVGraphics();


    //setAirline();
    m_cameraFrustum_  = new CameraFrustum(this,m_sceneView);
    m_UAVTextLabel_ = new UAVTextLabel(this,m_sceneView);
    m_targetImgLabel_ = new TargetImgLabel(this,m_sceneView);
    m_UAVTrack_ = new UAVTrack(this,m_sceneView);
    m_UAVLine_=new UAVLine(this,m_sceneView);
}

void NewGis::loadTif(QUrl img, QUrl elevation)
{
    qDebug()<<QString::fromLocal8Bit("进入loadTif函数,加载地图")<<endl;
    qDebug()<<img;
    qDebug()<<elevation;
    QString localimg = img.toLocalFile();
    QString localelvation = elevation.toLocalFile();
    Raster * raster = new Raster(localimg);
    RasterLayer * rl = new RasterLayer(raster);
    m_sceneView->arcGISScene()->operationalLayers()->append(rl);

    connect(rl,&RasterLayer::doneLoading,this,[this,rl](){
        Point centerPoint = rl->fullExtent().center();
        Point centerLLA = (Point)GeometryEngine::project(centerPoint,SpatialReference::wgs84());
        Camera ccam = m_sceneView->currentViewpointCamera();

        GeodeticDistanceResult distanceresult = GeometryEngine::distanceGeodetic(ccam.location(),centerLLA,
                                                                                 LinearUnit::meters(),
                                                                                 AngularUnit::degrees(),
                                                                                 GeodeticCurveType::Geodesic);
        qDebug()<<"distanceresult:"<<distanceresult.distance();
        double dis = sqrt(distanceresult.distance()*distanceresult.distance() + ccam.location().z()*
                          ccam.location().z());

        Camera cam(centerLLA.y(),centerLLA.x(),100000,0,0,0);
        m_sceneView->setViewpointCamera(cam,2);
    });


    QStringList rastersourcelist;
    QString source_ = localelvation;
    rastersourcelist<<source_;
    RasterElevationSource * ElevationSource = new RasterElevationSource(rastersourcelist);

    // add the elevation source to the scene to display elevation
    m_sceneView->arcGISScene()->baseSurface()->elevationSources()->append(ElevationSource);
    // Set scene to the scene view
}

void NewGis::displayElevation(QMouseEvent &event)
{
    Point pos = m_sceneView->screenToBaseSurface(event.x(),event.y());
    float _z = pos.z();
    pos = Point(pos.x(),pos.y(),0);
    //qDebug()<<"screencenter:"<<pos.y()<<","<<pos.x()<<","<<pos.z();
    double xx = pos.x();
    double yy = pos.y();

    // Place the elevation marker circle at the clicked position
    m_elevationMarker->setGeometry(pos);
    m_elevationMarker->setVisible(true);

    emit posChanged(xx,yy,_z);
    //qDebug()<<"xx="<<xx<<"yy="<<yy<<"_z"<<_z<<endl;

}

void NewGis::zoomOutScene()
{
    qDebug()<<QString::fromLocal8Bit("进入缩小函数")<<endl;
    Camera ccam = m_sceneView->currentViewpointCamera();
    Point pos = m_sceneView->screenToBaseSurface(m_sceneView->width()/2,m_sceneView->height() /2);
    GeodeticDistanceResult distanceresult = GeometryEngine::distanceGeodetic(ccam.location(),pos,
                                                                             LinearUnit::meters(),
                                                                             AngularUnit::degrees(),
                                                                             GeodeticCurveType::Geodesic);
    double dis = sqrt(distanceresult.distance()*distanceresult.distance() + ccam.location().z()*
                      ccam.location().z());
    double distance = dis * 2;
    Camera cam(pos,distance,ccam.heading(),ccam.pitch(),ccam.roll());
    m_sceneView->setViewpointCamera(cam,1);
}

void NewGis::zoomInScene()
{

    //qDebug()<<QString::fromLocal8Bit("进入放大函数")<<endl;
    Camera ccam = m_sceneView->currentViewpointCamera();
    Point pos = m_sceneView->screenToBaseSurface(m_sceneView->width()/2,m_sceneView->height() /2);
    GeodeticDistanceResult distanceresult = GeometryEngine::distanceGeodetic(ccam.location(),pos,
                                                                             LinearUnit::meters(),
                                                                             AngularUnit::degrees(),
                                                                             GeodeticCurveType::Geodesic);

    double dis = sqrt(distanceresult.distance()*distanceresult.distance() + ccam.location().z()*
                      ccam.location().z());
    double distance = dis * 0.5;
    Camera cam(pos,distance,ccam.heading(),ccam.pitch(),ccam.roll());
    m_sceneView->setViewpointCamera(cam,1);
}

void NewGis::orthoLookMap()
{
    //qDebug()<<QString::fromLocal8Bit("点击这里进行正射校正")<<endl;
    Camera ccam = m_sceneView->currentViewpointCamera();
    qDebug()<<"ccam:"<<ccam.location().x()<<","<<ccam.location().y()<<","<<ccam.location().z();
    Point pos = m_sceneView->screenToBaseSurface(m_sceneView->width()/2,m_sceneView->height() /2);
    qDebug()<<"pos:"<<pos.x()<<","<<pos.y()<<","<<pos.z();
    if(std::isnan(pos.x()))
    {
        Camera cam(ccam.location().y(),ccam.location().x(),500+ccam.location().z() ,0,0,0);
        m_sceneView->setViewpointCamera(cam,2);
        return;
    }
    Point centerLLA = (Point)GeometryEngine::project(pos,SpatialReference::wgs84());
    double xx = pos.x();
    double yy = pos.y();
    GeodeticDistanceResult distanceresult = GeometryEngine::distanceGeodetic(ccam.location(),pos,
                                                                             LinearUnit::meters(),
                                                                             AngularUnit::degrees(),
                                                                             GeodeticCurveType::Geodesic);
    qDebug()<<"distanceresult:"<<distanceresult.distance();
    double dis = sqrt(distanceresult.distance()*distanceresult.distance() + ccam.location().z()*
                      ccam.location().z());

    Camera cam(yy,xx,dis,0,0,0);

    m_sceneView->setViewpointCamera(cam,2);
}

void NewGis::perspectiveLookMap(float pitch)
{
    qDebug()<<QString::fromLocal8Bit("这里进行倾斜校正")<<endl;
    Camera ccam = m_sceneView->currentViewpointCamera();
    Point pos = m_sceneView->screenToBaseSurface(m_sceneView->width()/2,m_sceneView->height() /2);
    if(std::isnan(pos.x()))
    {
        Camera cam(ccam.location().y(),ccam.location().x(),500+ccam.location().z() ,0,45,0);
        m_sceneView->setViewpointCamera(cam,2);
        return;
    }

    Point centerLLA = (Point)GeometryEngine::project(pos,SpatialReference::wgs84());
    GeodeticDistanceResult distanceresult = GeometryEngine::distanceGeodetic(ccam.location(),pos,
                                                                             LinearUnit::meters(),
                                                                             AngularUnit::degrees(),
                                                                             GeodeticCurveType::Geodesic);

    double dis = sqrt(distanceresult.distance()*distanceresult.distance() + ccam.location().z()*
                      ccam.location().z());
    Camera cam(pos,dis,0,45,0);
    m_sceneView->setViewpointCamera(cam,2);
}



void NewGis::trackUAV(int UAVID)
{
    //qDebug()<<QString::fromLocal8Bit("开始进入trackUAV函数")<<endl;
    int graphicsIndex = m_UAVID_GraphicsPairs_[UAVID];

    qDebug()<<"UAVID="<<UAVID<<endl;
    //qDebug()<<"graphicsIndex="<<graphicsIndex<<endl;

    OrbitGeoElementCameraController * _tempController = m_UAVCameras_[graphicsIndex];

    m_sceneView->setCameraController(_tempController);
    //qDebug()<<QString::fromLocal8Bit("程序trackUAV结束")<<endl;
}

void NewGis::initUAVGraphics()
{
    //qDebug()<<endl;
    QString _cp = QDir::currentPath();
    _cp = _cp + "/drone_costum.obj";
    //_cp = _cp + "/E 45 Aircraft_obj.obj";
    //_cp = _cp + "/P-51 Mustang.obj";
    //_cp = _cp + "/Airplanewithouttexture.obj";
    // _cp = _cp + "/airPlane.obj";

    //created by 1119


    QString _cp1 = QDir::currentPath();
    _cp1 = _cp1 + "/UAV.obj";

    qDebug()<<_cp1<<endl;
    //从一开始就加载了

    if(_cp==nullptr)
    {
        qDebug()<<QString::fromLocal8Bit("没有找到飞机模型")<<endl;
    }
    //qDebug()<<QString::fromLocal8Bit("开始绘画飞机")<<endl;
    qDebug()<<"m_graphic3ds_.size()="<<m_graphic3ds_.size()<<endl;
    m_graphic3ds_.reserve(m_maxUAVGraphics_);
    qDebug()<<"m_graphic3ds_.size()="<<m_graphic3ds_.size()<<endl;
    qDebug()<<"--------"<<endl;
    //qDebug()<<"m_maxUAVGraphics_="<<m_maxUAVGraphics_<<endl;

//    if (!m_model3d)
//    {
//        m_model3d = new ModelSceneSymbol(QUrl(_cp), 0.5f, this);
//        qDebug()<<QString::fromLocal8Bit("进来没")<<endl;
//    }



    //qDebug()<<"m_model3d->loadError().message()="<<m_model3d->loadError().message()<<endl;
    //qDebug()<<"m_model3d->url().toString()="<<m_model3d->url().toString()<<endl;

//    connect(m_model3d,&ModelSceneSymbol::loadStatusChanged,this,[this](){
//        if(m_model3d->loadStatus() == LoadStatus::Loaded)
//        {
//            qDebug()<<m_model3d->loadError().message();
//            qDebug()<<m_model3d->url().toString();
//            qDebug()<<QString::fromLocal8Bit("进来没1111")<<endl;
//            Point airpos(0,0,-100,SpatialReference::wgs84());
//            for(size_t i =0; i < m_maxUAVGraphics_; i++)
//            {
//                Graphic * _tempGraphics
//                        = new Graphic(airpos,m_model3d,this);
//                _tempGraphics->attributes()->insertAttribute(HEADING, 0);
//                _tempGraphics->attributes()->insertAttribute(PITCH, 0);
//                _tempGraphics->attributes()->insertAttribute(ROLL, 0);

//                // add the graphic to the graphics overlay
//                m_sceneView->graphicsOverlays()->at(0)->graphics()->append(_tempGraphics);

//                OrbitGeoElementCameraController * _tempCamera =
//                        new OrbitGeoElementCameraController(_tempGraphics,100,this);

//                m_UAVCameras_.push_back(_tempCamera);

//                m_graphic3ds_.push_back(_tempGraphics);
//            }


//        }
//    });
//    m_model3d->load();

    if (!m_model3d)
    {
        m_model3d = new ModelSceneSymbol(QUrl(_cp), 0.5f, this);
        m_model3d_pairs_.push_back(m_model3d);
        m_model3d = new ModelSceneSymbol(QUrl(_cp1), 0.0005f, this);
        m_model3d_pairs_.push_back(m_model3d);
    }

    connect(m_model3d_pairs_[0],&ModelSceneSymbol::loadStatusChanged,this,[this](){
        if(m_model3d_pairs_[0]->loadStatus() == LoadStatus::Loaded)
        {
            //qDebug()<<m_model3d->loadError().message();
            //qDebug()<<m_model3d->url().toString();
            qDebug()<<"进去没"<<m_graphic3ds_.size()<<endl;
            Point airpos(0,0,-100,SpatialReference::wgs84());
            for(size_t i =0; i < m_maxUAVGraphics_; i++)
            {
                Graphic * _tempGraphics
                        = new Graphic(airpos,m_model3d_pairs_[0],this);
                _tempGraphics->attributes()->insertAttribute(HEADING, 0);
                _tempGraphics->attributes()->insertAttribute(PITCH, 0);
                _tempGraphics->attributes()->insertAttribute(ROLL, 0);

                // add the graphic to the graphics overlay
                m_sceneView->graphicsOverlays()->at(0)->graphics()->append(_tempGraphics);

                OrbitGeoElementCameraController * _tempCamera =
                        new OrbitGeoElementCameraController(_tempGraphics,100,this);

                m_UAVCameras_.push_back(_tempCamera);

                m_graphic3ds_.push_back(_tempGraphics);
            }

        }
    });
    m_model3d_pairs_[0]->load();

    qDebug()<<"m_graphic3ds_.size()="<<m_graphic3ds_.size()<<endl;

    connect(m_model3d_pairs_[1],&ModelSceneSymbol::loadStatusChanged,this,[this](){
        if(m_model3d_pairs_[1]->loadStatus() == LoadStatus::Loaded)
        {
            //qDebug()<<m_model3d->loadError().message();
            //qDebug()<<m_model3d->url().toString();
            Point airpos(0,0,-200,SpatialReference::wgs84());
            for(size_t i =0; i < m_maxUAVGraphics_; i++)
            {
                Graphic * _tempGraphics1
                        = new Graphic(airpos,m_model3d_pairs_[1],this);
                _tempGraphics1->attributes()->insertAttribute(HEADING, 0);
                _tempGraphics1->attributes()->insertAttribute(PITCH, 0);
                _tempGraphics1->attributes()->insertAttribute(ROLL, 0);

                // add the graphic to the graphics overlay
                m_sceneView->graphicsOverlays()->at(0)->graphics()->append(_tempGraphics1);

                OrbitGeoElementCameraController * _tempCamera =
                        new OrbitGeoElementCameraController(_tempGraphics1,200,this);

                m_UAVCameras_.push_back(_tempCamera);

                m_graphic3ds_.push_back(_tempGraphics1);
            }

        }
    });
    m_model3d_pairs_[1]->load();



    qDebug()<<QString::fromLocal8Bit("绘画飞机结束")<<endl;
}



void NewGis::receiveUAVInfo(const QB::QbImgPara * info)
{
    //qDebug()<<QString::fromLocal8Bit("开始监听飞机")<<endl;
//    if(m_graphic3ds_.size()<=0)
//        {
//        qDebug()<<QString::fromLocal8Bit("监听的飞机的数量为0")<<endl;
//        return;
//    }

    if(info==nullptr)
    {
        qDebug()<<"*******"<<endl;
    }

    qDebug()<<"info->airType="<<info->airType<<endl;

    qDebug()<<"m_graphic3ds_.size()="<<m_graphic3ds_.size()<<endl;

    if(m_UAVID_GraphicsPairs_.contains(info->airID))//refresh
    {
        //qDebug()<<QString::fromLocal8Bit("刷新飞机参数")<<endl;
        int graphicsIndex = m_UAVID_GraphicsPairs_[info->airID];

        Point _pos =  Point(info->lon, info->lat, info->alt - info->gdHeight, Esri::ArcGISRuntime::SpatialReference::wgs84());

        m_graphic3ds_[graphicsIndex]->setGeometry(_pos);
        m_graphic3ds_[graphicsIndex]->attributes()->replaceAttribute(HEADING,info->yaw);
        m_graphic3ds_[graphicsIndex]->attributes()->replaceAttribute(PITCH,info->pitch);
        m_graphic3ds_[graphicsIndex]->attributes()->replaceAttribute(ROLL,info->roll);
    }
    else {//add new UAV
        qDebug()<<QString::fromLocal8Bit("添加新的飞机模型")<<endl;
        //airCategory++;
        if(info->airType==8)
        {
            m_UAVID_GraphicsPairs_[info->airID] = m_UAVGraphicsCount_+12;

            Point _pos =  Point(info->lon, info->lat, info->alt- info->gdHeight, Esri::ArcGISRuntime::SpatialReference::wgs84());

            m_graphic3ds_[m_UAVID_GraphicsPairs_[info->airID]]->setGeometry(_pos);
            m_graphic3ds_[m_UAVID_GraphicsPairs_[info->airID]]->attributes()->replaceAttribute(HEADING,info->yaw);
            m_graphic3ds_[m_UAVID_GraphicsPairs_[info->airID]]->attributes()->replaceAttribute(PITCH,info->pitch);
            m_graphic3ds_[m_UAVID_GraphicsPairs_[info->airID]]->attributes()->replaceAttribute(ROLL,info->roll);

        }else
        {
            m_UAVID_GraphicsPairs_[info->airID] = m_UAVGraphicsCount_;

            Point _pos =  Point(info->lon, info->lat, info->alt- info->gdHeight, Esri::ArcGISRuntime::SpatialReference::wgs84());

            m_graphic3ds_[m_UAVGraphicsCount_]->setGeometry(_pos);
            m_graphic3ds_[m_UAVGraphicsCount_]->attributes()->replaceAttribute(HEADING,info->yaw);
            m_graphic3ds_[m_UAVGraphicsCount_]->attributes()->replaceAttribute(PITCH,info->pitch);
            m_graphic3ds_[m_UAVGraphicsCount_]->attributes()->replaceAttribute(ROLL,info->roll);
        }

//        m_UAVID_GraphicsPairs_[info->airID] = m_UAVGraphicsCount_;

//        Point _pos =  Point(info->lon, info->lat, info->alt- info->gdHeight, Esri::ArcGISRuntime::SpatialReference::wgs84());

//        m_graphic3ds_[m_UAVGraphicsCount_]->setGeometry(_pos);
//        m_graphic3ds_[m_UAVGraphicsCount_]->attributes()->replaceAttribute(HEADING,info->yaw);
//        m_graphic3ds_[m_UAVGraphicsCount_]->attributes()->replaceAttribute(PITCH,info->pitch);
//        m_graphic3ds_[m_UAVGraphicsCount_]->attributes()->replaceAttribute(ROLL,info->roll);

        m_UAVGraphicsCount_ ++;

        //更新新的飞机模型

        updateGroupMemberModel(info);
    }

    if(m_cameraFrustum_)
        m_cameraFrustum_->drawFrustum(info);

    if(m_UAVTextLabel_)
        m_UAVTextLabel_->drawTextLabel(info);

    if(m_UAVTrack_)
        m_UAVTrack_->drawTrack(info);
}




void NewGis::updateGroupMemberModel(const QB::QbImgPara *info)
{
    //qDebug()<<QString::fromLocal8Bit("进入更新updateGroupMemberModel函数")<<endl;
    std::shared_ptr<Awareness> data = Awareness::getInstance();
    if(data->getUnmannedDeviceInfo())
    {
        UnmannedDevice _tempDevice(info->airID,0,0,0,QString("%1").arg(info->airType),0,0,0);
        std::shared_ptr<std::vector<UnmannedDevice>> _UDs = data->getUnmannedDeviceInfo();
        _UDs->emplace_back(_tempDevice);
    }
    else {
        std::shared_ptr<std::vector<UnmannedDevice>> UDs(std::shared_ptr<std::vector<UnmannedDevice>>(new std::vector<UnmannedDevice>()));
        UnmannedDevice _tempDevice(info->airID,0,0,0,QString("%1").arg(info->airType),0,0,0);
        UDs->emplace_back(_tempDevice);
        data->updateUnmannedDevice(UDs);
    }
}

void NewGis::receiveTargetInfo(const tgGeos * info)
{
    if(m_targetImgLabel_)
        m_targetImgLabel_->drawTargetImgLabel(info);
}


//created by 1114  当有信号过来接受点
void NewGis::receiveUAVLineInfo(const LP::LinePoint * info)
{
    if(m_UAVLine_)
        m_UAVLine_->drawLine(info);
}

void NewGis::setAirline()
{
    qDebug()<<QString::fromLocal8Bit("进入函数setAirline")<<endl;


    //Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder;
    //Graphic * _tempGraphicsLine;


    showAirline++;
    if(showAirline%2==0)
    {
        qDebug()<<QString::fromLocal8Bit("显示地图的showAirline=")<<showAirline<<endl;
        QQueue<Esri::ArcGISRuntime::Point> m_LineQueue0;

        polylineBuilder=new PolylineBuilder(SpatialReference::wgs84());
        QFile loadFile("E:\\jiku\\3DAwarenessRefactor\\newGis\\LinePointJson.json");

        if(!loadFile.open(QIODevice::ReadOnly))
        {
            qDebug() << "could't open projects json";
        }

        QByteArray allData = loadFile.readAll();
        loadFile.close();

        QJsonParseError json_error;
        QJsonDocument jsonDoc(QJsonDocument::fromJson(allData, &json_error));

        if(json_error.error != QJsonParseError::NoError)
        {
            qDebug() << "json error!";
        }

        QJsonObject rootObj = jsonDoc.object();

        //json里面最开始的头
        QStringList keys = rootObj.keys();
        for(int i = 0; i < keys.size(); i++)
        {
            qDebug() << "key" << i << " is:" << keys.at(i);
        }

        if(rootObj.contains("LinePoint"))
        {
           QJsonArray subArray = rootObj.value("LinePoint").toArray();
           for(int i = 0; i< subArray.size(); i++)
           {
               //qDebug() << i<<" value is:" << subArray.at(i).toString();
               QStringList LinePointTemp=subArray.at(i).toString().split(",");
               Point p=Point(LinePointTemp[0].toDouble(),LinePointTemp[1].toDouble(),LinePointTemp[2].toDouble());
               m_LineQueue0.push_back(p);
           }
        }

        polylineBuilder->addPoints(m_LineQueue0);
        SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 6.0f /*width*/, this);

        //_tempGraphicsLine->setVisible(true);

        _tempGraphicsLine = new Graphic(Geometry(),simpleLineSymbol,this);
        //m_graphicsOverlay->graphics()->append(new Graphic(polylineBuilder.toGeometry(), simpleLineSymbol, this));
        //Graphic * _tempGraphicsLine = new Graphic(Geometry(),simpleLineSymbol,this);
       // _tempGraphicsLine->setGeometry(polylineBuilder.toGeometry());
        //m_sceneView->graphicsOverlays()->at(1)->graphics()->append(_tempGraphicsLine);
        //m_sceneView->graphicsOverlays()->append(m_graphicsOverlay);
        _tempGraphicsLine->setGeometry(polylineBuilder->toGeometry());
        m_sceneView->graphicsOverlays()->at(1)->graphics()->append(_tempGraphicsLine);
        //polylineBuilder=new PolylineBuilder(SpatialReference::wgs84());
        qDebug()<<"++++++++"<<endl;
    }
    if(showAirline%2!=0)
    {
        qDebug()<<QString::fromLocal8Bit("不显示地图的showAirline=")<<showAirline<<endl;
        //polylineBuilder=new PolylineBuilder(SpatialReference::wgs84());
        //polylineBuilder->toGeometry();
        //SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 6.0f /*width*/, this);
        //_tempGraphicsLine = new Graphic(Geometry(),simpleLineSymbol,this);
        _tempGraphicsLine->setVisible(false);
        m_sceneView->graphicsOverlays()->at(1)->graphics()->append(_tempGraphicsLine);
        qDebug()<<"do nothing"<<endl;
    }

}

void NewGis::setGlobeCamera()
{
    m_sceneView->setCameraController(m_globeCamera_);
}

void NewGis::loadModel()
{

}



