﻿#include "awareness.h"
std::shared_ptr<Awareness> Awareness::m_instance_ = nullptr;
Awareness::Awareness()
    :m_enemyTargets_(nullptr)
    ,m_unmannedDevices_(nullptr)
{
}

std::shared_ptr<Awareness> Awareness::getInstance()
{
    if(!m_instance_)
    {
        m_instance_ = std::shared_ptr<Awareness>(new Awareness);
        return m_instance_;
    }
    else
        return m_instance_;
}

void Awareness::updateEnemy(std::shared_ptr<std::vector<Enemy>> targets)
{

    m_enemyTargets_ = targets;

}

void Awareness::updateUnmannedDevice(std::shared_ptr<std::vector<UnmannedDevice>> devices)
{

    m_unmannedDevices_ = devices;

}

std::shared_ptr<std::vector<Enemy>> Awareness::getEnemyInfo() const
{
    return m_enemyTargets_;
}

std::shared_ptr<std::vector<UnmannedDevice>> Awareness::getUnmannedDeviceInfo() const
{
    return m_unmannedDevices_;
}
