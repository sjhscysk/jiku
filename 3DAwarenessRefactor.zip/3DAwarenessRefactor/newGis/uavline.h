﻿#ifndef UAVLINE_H
#define UAVLINE_H


#include <QObject>
#include <udplistener.h>
#include <SceneQuickView.h>
#include <QQueue>
#include"PolylineBuilder.h"

class UAVLine: public QObject
{
    Q_OBJECT

public:
     explicit UAVLine(QObject *parent = nullptr,Esri::ArcGISRuntime::SceneQuickView * sceneview = nullptr);
     void drawLine(const LP::LinePoint * info);

private:
    void updateLine(const LP::LinePoint * info);

    void addLine(const LP::LinePoint * info);

private:

    Esri::ArcGISRuntime::SceneQuickView * m_sceneView_;


    int m_maxCountLine_;
    int m_countLine_;
    QMap<int,size_t> m_UAVID_Line_;
    std::vector<Esri::ArcGISRuntime::Graphic*> m_LineGraphics_;

    //队列封装画出航线的点
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue0;
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue1;
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue2;

    //最多十二架飞机
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue3;
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue4;
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue5;
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue6;
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue7;
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue8;
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue9;
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue10;
    QQueue<Esri::ArcGISRuntime::Point> m_LineQueue11;



    //用来构造航线的点
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder1;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder2;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder0;

    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder3;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder4;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder5;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder6;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder7;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder8;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder9;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder10;
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder11;


};

#endif // UAVLINE_H
