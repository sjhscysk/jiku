﻿#include "uavtrack.h"
#include <TextSymbol.h>
#include<QDebug>

//created by 1111
#include "SimpleLineSymbol.h"
#include "SimpleMarkerSymbol.h"
#include "GraphicsOverlay.h"
#include "PolylineBuilder.h"

int i=0;
int j=0;
int Pointtemp=0;
int PointCount1=0;
Esri::ArcGISRuntime::Point temp;
//Esri::ArcGISRuntime::Point tempRoute;
int maxPointSum=100;
int caijidian=0;
int pointRouteCount=0;
int Track2=0;
using namespace Esri::ArcGISRuntime;


UAVTrack::UAVTrack(QObject *parent,Esri::ArcGISRuntime::SceneQuickView * sceneview) : QObject(parent)
  ,m_maxCountTrack_(12)
  ,m_countTrack_(0)
  ,m_sceneView_(sceneview)
{


}


void UAVTrack::drawTrack(const QB::QbImgPara *info)
{
    if(m_UAVID_Track_.contains(info->airID))
    {
        updateTrack(info);
    }
    else {
        i++;
        qDebug()<<"i="<<i<<endl;
        addTrack(info);
    }
}


void UAVTrack::updateTrack(const QB::QbImgPara *info)
{

    //qDebug()<<"info->airType="<<info->airType<<endl;
    if(info->alt-info->gdHeight>2.5)
    {
        //qDebug()<<"info->alt-info->gdHeight="<<info->alt-info->gdHeight<<endl;
        //qDebug()<<"-------"<<endl;

    if(m_TrackGraphics_.size()>3)
    {

        int _index_Track = m_UAVID_Track_[info->airID];
        //第一架飞机
        if(_index_Track==0)
        {

            caijidian++;
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue0.push_back(tempLine);
//            if(caijidian==100||caijidian==1100||caijidian==2100||caijidian==3100||caijidian==4100||caijidian==5100||caijidian==6100||caijidian==7100||caijidian==8100||caijidian==9100||caijidian==10100||caijidian==11100||caijidian==12100)
//            {
//                qDebug()<<"caijidian="<<caijidian<<endl;
//                qDebug()<<"info->lon="<<info->lon<<endl;
//                qDebug()<<"info->lat="<<info->lat<<endl;
//                qDebug()<<"info->alt="<<info->alt<<endl;
//                qDebug()<<"info->gdHeight="<<info->gdHeight<<endl;
//                qDebug()<<"info->alt-info->gdHeight="<<info->alt-info->gdHeight<<endl;
//            }
            if(m_TrackQueue0.size()>maxPointSum)
            {
                    m_TrackQueue0.pop_front();
            }

            if(m_TrackQueue0.size()==maxPointSum)
            {
                polytrackBuilder0=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder0->addPoints(m_TrackQueue0);
                m_TrackGraphics_[4]->setGeometry(polytrackBuilder0->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[4]);
            }
        }


        //第二架飞机
        if(_index_Track==1)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue1.push_back(tempLine);

            if(m_TrackQueue1.size()>maxPointSum)
            {
                    m_TrackQueue1.pop_front();
                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue1.size()<<endl;
            }

            if(m_TrackQueue1.size()==maxPointSum)
            {
                polytrackBuilder1=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder1->addPoints(m_TrackQueue1);
                m_TrackGraphics_[5]->setGeometry(polytrackBuilder1->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[5]);
            }
        }


        //第三架飞机
        if(_index_Track==2)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue2.push_back(tempLine);
            Track2++;
            qDebug()<<"Track2="<<Track2<<endl;
            if(m_TrackQueue2.size()>maxPointSum)
            {
                    m_TrackQueue2.pop_front();
                    qDebug()<<"m_TrackQueue2.size()="<<m_TrackQueue2.size()<<endl;
            }

            if(m_TrackQueue2.size()==maxPointSum)
            {
                polytrackBuilder2=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder2->addPoints(m_TrackQueue2);
                m_TrackGraphics_[6]->setGeometry(polytrackBuilder2->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[6]);
            }
        }


        //第四个飞机
        if(_index_Track==3)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue3.push_back(tempLine);

            if(m_TrackQueue3.size()>maxPointSum)
            {
                    m_TrackQueue3.pop_front();
                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue2.size()<<endl;
            }

            if(m_TrackQueue3.size()==maxPointSum)
            {
                polytrackBuilder3=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder3->addPoints(m_TrackQueue3);
                m_TrackGraphics_[7]->setGeometry(polytrackBuilder3->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[7]);
            }
        }

        //第五个飞机
        if(_index_Track==4)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue4.push_back(tempLine);

            if(m_TrackQueue4.size()>maxPointSum)
            {
                    m_TrackQueue4.pop_front();
                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue2.size()<<endl;
            }

            if(m_TrackQueue4.size()==maxPointSum)
            {
                polytrackBuilder4=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder4->addPoints(m_TrackQueue4);
                m_TrackGraphics_[8]->setGeometry(polytrackBuilder4->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[8]);
            }
        }

        //第六个飞机
        if(_index_Track==5)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue5.push_back(tempLine);

            if(m_TrackQueue5.size()>maxPointSum)
            {
                    m_TrackQueue5.pop_front();
                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue2.size()<<endl;
            }

            if(m_TrackQueue5.size()==maxPointSum)
            {
                polytrackBuilder5=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder5->addPoints(m_TrackQueue5);
                m_TrackGraphics_[9]->setGeometry(polytrackBuilder5->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[9]);
            }
        }

        //第七个飞机
        if(_index_Track==6)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue6.push_back(tempLine);

            if(m_TrackQueue6.size()>maxPointSum)
            {
                    m_TrackQueue6.pop_front();
                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue2.size()<<endl;
            }

            if(m_TrackQueue6.size()==maxPointSum)
            {
                polytrackBuilder6=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder6->addPoints(m_TrackQueue6);
                m_TrackGraphics_[10]->setGeometry(polytrackBuilder6->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[10]);
            }
        }

        //第八个飞机
        if(_index_Track==7)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue7.push_back(tempLine);

            if(m_TrackQueue7.size()>maxPointSum)
            {
                    m_TrackQueue7.pop_front();
                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue2.size()<<endl;
            }

            if(m_TrackQueue7.size()==maxPointSum)
            {
                polytrackBuilder7=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder7->addPoints(m_TrackQueue7);
                m_TrackGraphics_[11]->setGeometry(polytrackBuilder7->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[11]);
            }
        }

        //第九个飞机
        if(_index_Track==8)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue8.push_back(tempLine);

            if(m_TrackQueue8.size()>maxPointSum)
            {
                    m_TrackQueue8.pop_front();
                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue2.size()<<endl;
            }

            if(m_TrackQueue8.size()==maxPointSum)
            {
                polytrackBuilder8=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder8->addPoints(m_TrackQueue8);
                m_TrackGraphics_[12]->setGeometry(polytrackBuilder8->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[12]);
            }
        }

        //第十个飞机
        if(_index_Track==9)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue9.push_back(tempLine);

            if(m_TrackQueue9.size()>maxPointSum)
            {
                    m_TrackQueue9.pop_front();
                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue2.size()<<endl;
            }

            if(m_TrackQueue9.size()==maxPointSum)
            {
                polytrackBuilder9=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder9->addPoints(m_TrackQueue9);
                m_TrackGraphics_[13]->setGeometry(polytrackBuilder9->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[13]);
            }
        }

        //第十一个飞机
        if(_index_Track==10)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue10.push_back(tempLine);

            if(m_TrackQueue10.size()>maxPointSum)
            {
                    m_TrackQueue10.pop_front();
                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue2.size()<<endl;
            }

            if(m_TrackQueue10.size()==maxPointSum)
            {
                polytrackBuilder10=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder10->addPoints(m_TrackQueue10);
                m_TrackGraphics_[14]->setGeometry(polytrackBuilder10->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[14]);
            }
        }

        //第十二个飞机
        if(_index_Track==11)
        {
            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
            m_TrackQueue11.push_back(tempLine);

            if(m_TrackQueue11.size()>maxPointSum)
            {
                    m_TrackQueue11.pop_front();
                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue2.size()<<endl;
            }

            if(m_TrackQueue11.size()==maxPointSum)
            {
                polytrackBuilder11=new PolylineBuilder(SpatialReference::wgs84());
                polytrackBuilder11->addPoints(m_TrackQueue11);
                m_TrackGraphics_[15]->setGeometry(polytrackBuilder11->toGeometry());
                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_TrackGraphics_[15]);
            }
        }

      }

    }
}

void UAVTrack::addTrack(const QB::QbImgPara *info)
{
    SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 3.0f /*width*/, this);
    Graphic * _tempGraphicsTrack = new Graphic(Geometry(),simpleLineSymbol,this);
    m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempGraphicsTrack);
    Point _posTrack = Point(info->lon,info->lat,info->alt- info->gdHeight,SpatialReference::wgs84());
    _tempGraphicsTrack->setGeometry(_posTrack);


    m_TrackGraphics_.push_back(_tempGraphicsTrack);
    m_UAVID_Track_[info->airID] = m_countTrack_;

    //qDebug()<<"info->airID="<<info->airID<<"-----"<<"m_countTrack_="<<m_countTrack_<<endl;
    m_countTrack_++;

    if(i==1)
    {
        for(int k=4;k<17;k++)
        {
            SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("blue"), 3.0f /*width*/, this);
            Graphic * _tempGraphicsTrack = new Graphic(Geometry(),simpleLineSymbol,this);
            m_TrackGraphics_.push_back(_tempGraphicsTrack);
        }
    }
}



