﻿#include "enemy.h"


Enemy::Enemy(int uuid, double lon, double lat, double alt, QString type, int importance)
    :m_uuid(uuid)
    ,m_lon(lon)
    ,m_lat(lat)
    ,m_alt(alt)
    ,m_type(type)
    ,m_importance(importance)
{

}
