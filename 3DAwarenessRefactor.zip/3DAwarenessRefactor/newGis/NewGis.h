﻿
// Copyright 2019 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// You may freely redistribute and use this sample code, with or
// without modification, provided you include the original copyright
// notice and use restrictions.
//
// See the Sample code usage restrictions document for further information.
//

#ifndef NEWGIS_H
#define NEWGIS_H

namespace Esri
{
namespace ArcGISRuntime
{
class Scene;
class SceneQuickView;
//created by 1103
class GlobeCameraController;
class Graphic;
class GraphicsOverlay;
class MapQuickView;
class ModelSceneSymbol;
class OrbitGeoElementCameraController;
class SceneQuickView;
class SimpleMarkerSymbol;
class GlobeCameraController;
//created by zh draw the line
class SimpleLineSymbol;
class SimpleMarkerSymbol;
}
}

#include <QObject>

#include <QQuickItem>
#include <GraphicsOverlay.h>
#include <Graphic.h>


//created by 1104
#include<QbImgPara.h>
#include <udplistener.h>
#include <camerafrustum.h>
#include <uavtextlabel.h>
#include <targetimglabel.h>

//created by 1114
#include <uavtrack.h>
#include <uavline.h>


class NewGis : public QObject
{
    Q_OBJECT

    Q_PROPERTY(Esri::ArcGISRuntime::SceneQuickView* sceneView READ sceneView WRITE setSceneView NOTIFY sceneViewChanged)

public:
    explicit NewGis(QObject* parent = nullptr);
    ~NewGis() override;
    //created by 1103
    Q_INVOKABLE void loadTif(QUrl img,QUrl elevation);
    Q_INVOKABLE void orthoLookMap();
    Q_INVOKABLE void perspectiveLookMap(float pitch = 0);
    Q_INVOKABLE void zoomInScene();
    Q_INVOKABLE void zoomOutScene();
    Q_INVOKABLE void loadModel();

    //created by 1114
    Q_INVOKABLE void setAirline();

    //created by 1104
    Q_INVOKABLE void trackUAV(int UAVID);
    Q_INVOKABLE void setGlobeCamera();


private:
      //created by 1104
      void receiveUAVInfo(const QB::QbImgPara * info);
      void receiveTargetInfo(const tgGeos * info);

      //created by 1114
      void receiveUAVLineInfo(const LP::LinePoint * info);


signals:
    void sceneViewChanged();
    //created by 1103
    void posChanged(double lon,double lat,double alt);



private:
    //created by 1103
    void displayElevation(QMouseEvent &event);
    Esri::ArcGISRuntime::SceneQuickView* sceneView() const;
    void setSceneView(Esri::ArcGISRuntime::SceneQuickView* sceneView);

    //created by 1104 加载飞机模型
    void initUAVGraphics();
    void updateGroupMemberModel(const QB::QbImgPara *info);


private:
    Esri::ArcGISRuntime::Scene* m_scene = nullptr;
    Esri::ArcGISRuntime::SceneQuickView* m_sceneView = nullptr;


    //created by 1103
    Esri::ArcGISRuntime::GraphicsOverlay* m_graphicsOverlay = nullptr;
    Esri::ArcGISRuntime::GraphicsOverlay* m_graphicsOverlayFrustum = nullptr;
    Esri::ArcGISRuntime::Graphic* m_elevationMarker = nullptr;
    Esri::ArcGISRuntime::Graphic* m_lineMarker = nullptr;


    Esri::ArcGISRuntime::ModelSceneSymbol* m_model3d = nullptr;

    //created by 1119
    std::vector<Esri::ArcGISRuntime::ModelSceneSymbol*> m_model3d_pairs_;


    //画出飞机的图层
    std::vector<Esri::ArcGISRuntime::Graphic*> m_graphic3ds_;


    std::vector<Esri::ArcGISRuntime::OrbitGeoElementCameraController *> m_UAVCameras_;
    Esri::ArcGISRuntime::GlobeCameraController * m_globeCamera_;

    QMap<int,size_t> m_UAVID_GraphicsPairs_;

    double m_myLon_;
    double m_myLat_;
    double m_myAlt_;
    double m_camDistance_;

    //created by 1104
    UDPListener * m_listener_;

    //定义飞机最大的数量  created by 1119
    int m_maxUAVGraphics_;
    //定义当前飞机的数量
    int m_UAVGraphicsCount_ ;


    //created by 1104

    CameraFrustum * m_cameraFrustum_;
    UAVTextLabel * m_UAVTextLabel_;

    TargetImgLabel  * m_targetImgLabel_;

    //created by 1114
    UAVTrack *m_UAVTrack_;
    UAVLine *m_UAVLine_;

    //created by 1116
    Esri::ArcGISRuntime::PolylineBuilder *polylineBuilder;
    Esri::ArcGISRuntime::Graphic * _tempGraphicsLine;
};

#endif // NEWGIS_H
