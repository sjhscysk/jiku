﻿#include "uavtextlabel.h"
#include <TextSymbol.h>
#include<QDebug>

//created by 1111
#include "SimpleLineSymbol.h"
#include "SimpleMarkerSymbol.h"
#include "GraphicsOverlay.h"
#include "PolylineBuilder.h"

//int i=0;
//int j=0;
//int Pointtemp=0;
//int PointCount1=0;
//Esri::ArcGISRuntime::Point temp;
//Esri::ArcGISRuntime::Point tempRoute;
//int maxPointSum=100;

//int pointRouteCount=0;
using namespace Esri::ArcGISRuntime;
UAVTextLabel::UAVTextLabel(QObject *parent,Esri::ArcGISRuntime::SceneQuickView * sceneview) : QObject(parent)
  ,m_maxCountLabel_(12)
  ,m_countLabel_(0)
  ,m_maxCountLine_(12)
  ,m_countLine_(0)
  ,m_maxCountLine1_(12)
  ,m_countLine1_(0)
  ,m_maxCountLine2_(12)
  ,m_countLine2_(0)
  ,polylineBuilder(SpatialReference::wgs84())
  //,polylineBuilder1(SpatialReference::wgs84())
  //,polylineBuilder2(SpatialReference::wgs84())
  //,polylineBuilder3(SpatialReference::wgs84())
  //,polylineBuilder0(SpatialReference::wgs84())
  ,m_maxCountPoint_(12)
  ,m_countPoint_(0)
  ,m_sceneView_(sceneview)
{
    //polylineBuilder0=new PolylineBuilder(SpatialReference::wgs84());


    SimpleMarkerSymbol* simpleMarkerSymbol2 = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle::Diamond, QColor("blue"), 32.0f /*size*/, this);
    Graphic * _tempGraphicsPoint10 = new Graphic(Geometry(),simpleMarkerSymbol2,this);
}

void UAVTextLabel::drawTextLabel(const QB::QbImgPara *info)
{
    if(m_UAVID_LabelPairs_.contains(info->airID))
    {
        updateTextLabel(info);
    }
    else {
        //i++;
        //qDebug()<<"i="<<i<<endl;
        addTextLabel(info);
    }
}

//m_maxCountLabel_代表的是飞机的最大数量12台  m_countLabel_代表的是当前飞机的数量
void UAVTextLabel::updateTextLabel(const QB::QbImgPara *info)
{
    //qDebug()<<QString::fromLocal8Bit("---进入更新飞机的参数---")<<endl;

    // QMap<int,size_t> m_UAVID_LabelPairs_;  size_t无符号整数类型

    int _index = m_UAVID_LabelPairs_[info->airID];
    m_textLabelGraphics_[_index]->setGeometry(Point(info->lon,info->lat,info->alt-info->gdHeight + 10,SpatialReference::wgs84()));
    m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_textLabelGraphics_[_index]);




//    int _index_Point = m_UAVID_PointPairs_[info->airID];
//    m_PointGraphics_[_index_Point]->setGeometry(Point(info->lon,info->lat,info->alt-info->gdHeight + 10,SpatialReference::wgs84()));
//    m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_PointGraphics_[_index_Point]);



//    int _index_Line = m_UAVID_Lines1_[info->airID];

//    if(m_LineGraphics1_.size()>3)
//    {
//        if(_index_Line==0)
//        {

//            //画出航迹的点
//            pointRouteCount++;
//            if(pointRouteCount==50||pointRouteCount==100||pointRouteCount==150||pointRouteCount==200)
//            {
//                qDebug()<<"pointRouteCount="<<pointRouteCount<<endl;
//                Point PointCount=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
//                m_PointRoute.push_back(PointCount);

//            }

//            if(m_PointRoute.size()==4)
//            {
//                qDebug()<<"m_PointRoute.size()=="<<m_PointRoute.size()<<endl;
//                polylineBuilder3=new PolylineBuilder(SpatialReference::wgs84());
//                polylineBuilder3->addPoints(m_PointRoute);
//                SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("orange"), 15.0f /*width*/, this);
//                Graphic * _RouteGraphicsLine = new Graphic(Geometry(),simpleLineSymbol,this);
//                _RouteGraphicsLine->setGeometry(polylineBuilder3->toGeometry());
//                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_RouteGraphicsLine);

//            }



//            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
//            m_PointQueue.push_back(tempLine);

//            if(m_PointQueue.size()>maxPointSum)
//            {
//                    m_PointQueue.pop_front();
//                    //qDebug()<<"m_PointQueue.size()="<<m_PointQueue.size()<<endl;
//            }

//            if(m_PointQueue.size()==maxPointSum)
//            {
//                polylineBuilder0=new PolylineBuilder(SpatialReference::wgs84());
//                polylineBuilder0->addPoints(m_PointQueue);
//                m_LineGraphics1_[4]->setGeometry(polylineBuilder0->toGeometry());
//                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_LineGraphics1_[4]);
//            }
//        }


//        //第二架飞机
//        if(_index_Line==1)
//        {
//            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
//            m_PointQueue1.push_back(tempLine);

//            if(m_PointQueue1.size()>maxPointSum)
//            {
//                    m_PointQueue1.pop_front();
//                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue1.size()<<endl;
//            }

//            if(m_PointQueue1.size()==maxPointSum)
//            {
//                polylineBuilder1=new PolylineBuilder(SpatialReference::wgs84());
//                polylineBuilder1->addPoints(m_PointQueue1);
//                m_LineGraphics1_[5]->setGeometry(polylineBuilder1->toGeometry());
//                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_LineGraphics1_[5]);
//            }
//        }


//        //第三架飞机
//        if(_index_Line==2)
//        {
//            Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84());
//            m_PointQueue2.push_back(tempLine);

//            if(m_PointQueue2.size()>maxPointSum)
//            {
//                    m_PointQueue2.pop_front();
//                    //qDebug()<<"m_PointQueue1.size()="<<m_PointQueue2.size()<<endl;
//            }

//            if(m_PointQueue2.size()==maxPointSum)
//            {
//                polylineBuilder2=new PolylineBuilder(SpatialReference::wgs84());
//                polylineBuilder2->addPoints(m_PointQueue2);
//                m_LineGraphics1_[6]->setGeometry(polylineBuilder2->toGeometry());
//                m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_LineGraphics1_[6]);
//            }
//        }

//    }





    //1113描述点成功
//    if(m_PointGraphics_.size()>10)
//    {
//        if(_index_Point==0)
//        {
//                  Point tempLine=Point(info->lon,info->lat,info->alt-info->gdHeight-5,SpatialReference::wgs84());
//                  m_PointQueue.push_back(tempLine);
//                  //m_PointVector.push_back(tempLine);
//                  qDebug()<<"----"<<m_PointQueue.size()<<endl;
//                  if(m_PointQueue.size()>10)
//                  {
//                      m_PointQueue.pop_front();
//                      qDebug()<<"********"<<m_PointQueue.size()<<endl;
//                  }
//                  m_PointGraphics_[4]->setGeometry(m_PointQueue[m_PointQueue.size()-1]);
//                  m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_PointGraphics_[4]);

//                  if(m_PointQueue.size()>1)
//                  {
//                      qDebug()<<"++++++"<<endl;
//                      m_PointGraphics_[5]->setGeometry(m_PointQueue[m_PointQueue.size()-2]);
//                      m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_PointGraphics_[5]);

//                  }

//                  if(m_PointQueue.size()>2)
//                  {
//                      //qDebug()<<"++++++"<<endl;
//                      m_PointGraphics_[6]->setGeometry(m_PointQueue[m_PointQueue.size()-3]);
//                      m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_PointGraphics_[6]);

//                  }

//                  if(m_PointQueue.size()>3)
//                  {
//                      //qDebug()<<"++++++"<<endl;
//                      m_PointGraphics_[7]->setGeometry(m_PointQueue[m_PointQueue.size()-4]);
//                      m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_PointGraphics_[7]);

//                  }

//                  if(m_PointQueue.size()>4)
//                  {
//                      //qDebug()<<"++++++"<<endl;
//                      m_PointGraphics_[8]->setGeometry(m_PointQueue[m_PointQueue.size()-5]);
//                      m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_PointGraphics_[8]);

//                  }

//                  if(m_PointQueue.size()>5)
//                  {
//                      //qDebug()<<"++++++"<<endl;
//                      m_PointGraphics_[9]->setGeometry(m_PointQueue[m_PointQueue.size()-6]);
//                      m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_PointGraphics_[9]);

//                  }

//                  if(m_PointQueue.size()>6)
//                  {
//                      //qDebug()<<"++++++"<<endl;
//                      m_PointGraphics_[10]->setGeometry(m_PointQueue[m_PointQueue.size()-7]);
//                      m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_PointGraphics_[10]);

//                  }

//                  if(m_PointQueue.size()>7)
//                  {
//                      //qDebug()<<"++++++"<<endl;
//                      m_PointGraphics_[11]->setGeometry(m_PointQueue[m_PointQueue.size()-8]);
//                      m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_PointGraphics_[11]);

//                  }

//        }
//    }




//    Pointtemp++;
//    Point tempLine=Point(info->lon,info->lat,info->alt- info->gdHeight);
//    m_PointList.push_back(tempLine);
//    std::list<Esri::ArcGISRuntime::Point>::iterator iter;
//    if(Pointtemp==200)
//    {
//          for(iter=m_PointList.begin();iter!=m_PointList.end();iter++)
//          {
//              //qDebug()<<(*iter).x()<<endl;
//              m_PointGraphics_[6]->setGeometry((*iter));
//              m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_PointGraphics_[6]);
//          }

//    }


    //qDebug()<<"info->airID="<<info->airID<<endl;
    //qDebug()<<"_index="<<_index<<endl;

    //经度，纬度，飞机的高度减去地面高度  _index的值代表0-12

    //std::vector<Esri::ArcGISRuntime::Graphic*> m_textLabelGraphics_;




    //通过点的叠加来画出路径

    //这个方法太卡，有问题
    //SimpleMarkerSymbol* simpleMarkerSymbol2 = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle::Diamond, QColor("blue"), 18.0f /*size*/, this);
    //m_LineGraphics_[_index_line]->graphics()->append(new Graphic(Point(info->lon,info->lat,info->alt-info->gdHeight + 10,SpatialReference::wgs84()), simpleMarkerSymbol2, this));

    //第二种添加点的方法  成功

//    SimpleMarkerSymbol* simpleMarkerSymbol2 = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle::Diamond, QColor("blue"), 18.0f /*size*/, this);
//    int _indexLine = m_UAVID_Lines1_[info->airID];
//    m_LineGraphics1_[_indexLine]=new Graphic(Geometry(),simpleMarkerSymbol2,this);
//    m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_LineGraphics1_[_indexLine]);
//    m_LineGraphics1_[_indexLine]->setGeometry(Point(info->lon,info->lat,info->alt-info->gdHeight,SpatialReference::wgs84()));



    //第二种添加线条的方法，通过线条添加飞机路径

//     int _index_line=m_UAVID_Lines1_[info->airID];
//     if(_index_line==0)
//     {


//         Pointtemp++;
//         Point tempLine=Point(info->lon,info->lat,info->alt- info->gdHeight);
//         m_PointList.push_back(tempLine);
//         //polylineBuilder0=new PolylineBuilder(SpatialReference::wgs84());





//         polylineBuilder0->addPoint(info->lon,info->lat,info->alt- info->gdHeight);
//         SimpleLineSymbol* simpleLineSymbol1= new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 7.0f /*width*/, this);
//         m_LineGraphics1_[_index_line]=new Graphic(Geometry(),simpleLineSymbol1,this);
//         m_LineGraphics1_[_index_line]->setGeometry(polylineBuilder0->toGeometry());
//         m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_LineGraphics1_[_index_line]);




//     }







    //第一种方法添加
//    int _index_line=m_UAVID_Lines_[info->airID];
//    if(_index_line==0)
//    {
//        polylineBuilder0.addPoint(info->lon,info->lat,info->alt);
//        SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 3.0f /*width*/, this);
//        m_LineGraphics_[_index_line]->graphics()->append(new Graphic(polylineBuilder0.toGeometry(), simpleLineSymbol, this));
//    }

//    if(_index_line==1)
//    {
//        polylineBuilder1.addPoint(info->lon,info->lat,info->alt);
//        SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 3.0f /*width*/, this);
//        m_LineGraphics_[_index_line]->graphics()->append(new Graphic(polylineBuilder1.toGeometry(), simpleLineSymbol, this));
//    }

//    if(_index_line==2)
//    {
//        polylineBuilder2.addPoint(info->lon,info->lat,info->alt);
//        SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 3.0f /*width*/, this);
//        m_LineGraphics_[_index_line]->graphics()->append(new Graphic(polylineBuilder2.toGeometry(), simpleLineSymbol, this));
//    }




    //qDebug()<<"---------------"<<endl;
}

void UAVTextLabel::addTextLabel(const QB::QbImgPara *info)
{


    //这是在界面中的展示
    //qDebug()<<QString::fromLocal8Bit("---进入添加新的飞机---")<<endl;

    TextSymbol * _symbol = new TextSymbol(QString::fromLocal8Bit(("编号:%1")).arg(info->airID),QColor(255,0,0,255),15,HorizontalAlignment::Center,
                                          VerticalAlignment::Middle,this);
    Graphic * _tempGraphics = new Graphic(Geometry(),_symbol,this);
    m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempGraphics);
    Point _pos = Point(info->lon,info->lat,info->alt- info->gdHeight,SpatialReference::wgs84());
    _tempGraphics->setGeometry(_pos);
    m_textLabelGraphics_.push_back(_tempGraphics);
    m_UAVID_LabelPairs_[info->airID] = m_countLabel_;
    m_countLabel_ ++;


    //第二种方法测试线条
//    SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 3.0f /*width*/, this);
//    Graphic * _tempGraphicsLine = new Graphic(Geometry(),simpleLineSymbol,this);
//    m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempGraphicsLine);
//    Point _posLine = Point(info->lon,info->lat,info->alt- info->gdHeight,SpatialReference::wgs84());
//    _tempGraphicsLine->setGeometry(_posLine);
//    m_LineGraphics1_.push_back(_tempGraphicsLine);
//    m_UAVID_Lines1_[info->airID] = m_countLine1_;
//    m_countLine1_++;

//    if(i==3)
//    {
//        for(int k=4;k<8;k++)
//        {
//            SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("blue"), 3.0f /*width*/, this);
//            Graphic * _tempGraphicsLine = new Graphic(Geometry(),simpleLineSymbol,this);
//            m_LineGraphics1_.push_back(_tempGraphicsLine);
//        }
//    }

    //第二种方法测试点成功
//    SimpleMarkerSymbol* simpleMarkerSymbol2 = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle::Diamond, QColor("red"), 18.0f /*size*/, this);
//    Graphic * _tempGraphicsPoint = new Graphic(Geometry(),simpleMarkerSymbol2,this);
//    m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempGraphicsPoint);
//    Point _pos1 = Point(info->lon,info->lat,info->alt- info->gdHeight,SpatialReference::wgs84());
//    _tempGraphicsPoint->setGeometry(_pos1);
//    m_PointGraphics_.push_back(_tempGraphicsPoint);
//    m_UAVID_PointPairs_[info->airID] = m_countPoint_;
//    m_countPoint_++;



//    if(i==3)
//    {
//        for(int k=4;k<14;k++)
//        {
//            SimpleMarkerSymbol* simpleMarkerSymbol2 = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle::Diamond, QColor("blue"), 18.0f /*size*/, this);
//            Graphic * _tempGraphicsPoint = new Graphic(Geometry(),simpleMarkerSymbol2,this);
//            m_PointGraphics_.push_back(_tempGraphicsPoint);
//        }
//    }




    // 测试线条成功  Create a simple line symbol - used to render a polyline border between California and Nevada.
    //const SpatialReference spatialRef(SpatialReference::wgs84());
    //PolylineBuilder polylineBuilder(spatialRef);

    // Add a graphic to the graphic collection - polyline with a simple line symbol.

//第一种方法测试封闭路径
//    if(i==1)
//    {
//        temp=Point(info->lon,info->lat,info->alt- info->gdHeight);
//    }
//    polylineBuilder.addPoint(info->lon,info->lat,info->alt- info->gdHeight);
//    if(i==3)
//    {
//        SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 7.0f /*width*/, this);
//        qDebug()<<"aaaaaaaa"<<endl;
//        polylineBuilder.addPoint(temp);
//        m_graphicsOverlay->graphics()->append(new Graphic(polylineBuilder.toGeometry(),simpleLineSymbol, this));
//        m_sceneView_->graphicsOverlays()->append(m_graphicsOverlay);
//    }

//第二种方法画出线条封闭路径
//    if(i==1)
//    {
//          temp=Point(info->lon,info->lat,info->alt- info->gdHeight);
//    }
//    polylineBuilder.addPoint(info->lon,info->lat,info->alt- info->gdHeight);
//    if(i==3)
//    {
//        SimpleLineSymbol* simpleLineSymbol1= new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 7.0f /*width*/, this);
//        Graphic * _tempGraphicsLine = new Graphic(Geometry(),simpleLineSymbol1,this);
//        m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempGraphicsLine);
//        polylineBuilder.addPoint(temp);
//        _tempGraphicsLine->setGeometry(polylineBuilder.toGeometry());
//    }


    //画出点，测试成功。第一种方法
   // SimpleMarkerSymbol* simpleMarkerSymbol2 = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle::Diamond, QColor("blue"), 18.0f /*size*/, this);
  //    GraphicsOverlay *m_graphicsOverlay=new GraphicsOverlay();
  //    m_graphicsOverlay->graphics()->append(new Graphic(_pos, simpleMarkerSymbol2, this));
  //    m_sceneView_->graphicsOverlays()->append(m_graphicsOverlay);











    //m_LineGraphics1_.push_back(_tempGraphicsPoint);
    //将飞机依次压入栈

    //m_LineGraphics_.push_back(m_graphicsOverlay);






    //同样的道理
    //m_UAVID_Lines_[info->airID] = m_countLine_;


    //m_countLine_++;

}


Geometry UAVTextLabel::createPoint(const QB::QbImgPara *info)
{
    double x = info->lon;
    double y = info->lat;
    const SpatialReference spatialRef(4326);

    // Return a map point where the Esri headquarters is located.
    return Point(x, y, spatialRef);
}

Geometry UAVTextLabel::createPolyline(const QB::QbImgPara *info)
{
  // Create a polyline builder
  const SpatialReference spatialRef(SpatialReference::wgs84());
  PolylineBuilder polylineBuilder(spatialRef);


  polylineBuilder.addPoint(info->lon,info->lat,info->alt- info->gdHeight);


  // add points to the builder that approximates the border between California and Nevada.


  //polylineBuilder.addPoint(-119.994, 38.994);
  //polylineBuilder.addPoint(-114.620, 35.0);

  // Return the geometry.
  return polylineBuilder.toGeometry();
}


