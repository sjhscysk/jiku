﻿#ifndef TARGETIMGLABEL_H
#define TARGETIMGLABEL_H

#include <QObject>
#include <udplistener.h>
#include <SceneQuickView.h>
class TargetImgLabel : public QObject
{
    Q_OBJECT
public:
    explicit TargetImgLabel(QObject *parent = nullptr,Esri::ArcGISRuntime::SceneQuickView * sceneview  = nullptr);
    void drawTargetImgLabel(const tgGeos * info);
 private:
        int m_maxCountFrustum_;
    int m_countFrustum_;
    Esri::ArcGISRuntime::SceneQuickView * m_sceneView_;
    QMap<int,size_t> m_UAVID_PolygonPairs_;
    std::vector<std::vector<Esri::ArcGISRuntime::Graphic*>> m_frustumGraphics_;
};

#endif // TARGETIMGLABEL_H
