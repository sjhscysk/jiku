﻿#ifndef AWARENESS_H
#define AWARENESS_H

#include <vector>
#include <memory>
class Enemy;
class UnmannedDevice;
class  Awareness
{
public:
    Awareness();
    static std::shared_ptr<Awareness> getInstance();
    void updateEnemy(std::shared_ptr<std::vector<Enemy>> targets);
    void updateUnmannedDevice(std::shared_ptr<std::vector<UnmannedDevice>> devices);
    std::shared_ptr<std::vector<Enemy>> getEnemyInfo() const;
    std::shared_ptr<std::vector<UnmannedDevice>> getUnmannedDeviceInfo() const;
private:
    static std::shared_ptr<Awareness> m_instance_;
    std::shared_ptr<std::vector<Enemy>> m_enemyTargets_;
    std::shared_ptr<std::vector<UnmannedDevice>> m_unmannedDevices_;
};


#endif // AWARENESS_H
