﻿#include "unmanneddevice.h"


UnmannedDevice::UnmannedDevice(int uuid, double lon, double lat, double alt, QString type,float heading,float pitch,float roll)
    :m_uuid(uuid)
    ,m_lon(lon)
    ,m_lat(lat)
    ,m_alt(alt)
    ,m_type(type)
    ,m_heading(heading)
    ,m_pitch(pitch)
    ,m_roll(roll)
{

}
