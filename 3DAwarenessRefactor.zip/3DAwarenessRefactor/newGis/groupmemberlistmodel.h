﻿#ifndef GROUPMEMBERLISTMODEL_H
#define GROUPMEMBERLISTMODEL_H

#include <memory>
#include <QAbstractListModel>
class Awareness;
class UnmannedDevice;
class GroupMemberListModel : public QAbstractListModel
{
    Q_OBJECT

public:
    explicit GroupMemberListModel(QObject *parent = nullptr);
    enum {
        NameRole = Qt::UserRole + 5,
        IDRole,
        LongitudeRole,
        LatitudeRole,
    };
    // Basic functionality:
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    virtual QHash<int, QByteArray> roleNames() const override;


private:
    std::shared_ptr<Awareness> m_awarenessObj_;
    std::shared_ptr<std::vector<UnmannedDevice>> m_memberList_;
};

#endif // GROUPMEMBERLISTMODEL_H
