﻿#include "groupmemberlistmodel.h"
#include <awareness.h>
#include <unmanneddevice.h>
GroupMemberListModel::GroupMemberListModel(QObject *parent)
    : QAbstractListModel(parent)
{
    m_awarenessObj_ = Awareness::getInstance();
    m_memberList_ = m_awarenessObj_->getUnmannedDeviceInfo();
}

int GroupMemberListModel::rowCount(const QModelIndex &parent) const
{
    // For list models only the root node (an invalid parent) should return the list's size. For all
    // other (valid) parents, rowCount() should return 0 so that it does not become a tree model.
    if (parent.isValid()||!m_memberList_)
        return 0;
    return m_memberList_->size();
    // FIXME: Implement me!
}

QVariant GroupMemberListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid()||!m_memberList_)
        return QVariant();
    UnmannedDevice &targetitem = m_memberList_->at(index.row());
    switch (role) {
    case NameRole:
        return targetitem.getType();
    case IDRole:
        return targetitem.getUUID();
    case LongitudeRole:
        return targetitem.getLongitude();
    case LatitudeRole:
        return targetitem.getLatitude();
    }
    // FIXME: Implement me!
    return QVariant();
}

QHash<int, QByteArray> GroupMemberListModel::roleNames() const
{
    QHash<int, QByteArray> names;
    names[NameRole] = "name";
    names[IDRole] = "ID";
    names[LongitudeRole] = "lon";
    names[LatitudeRole] = "lat";
    return names;
}
