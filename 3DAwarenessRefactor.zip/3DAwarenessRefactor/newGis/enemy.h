﻿#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QString>
class Enemy
{
public:
    Enemy(int uuid,double lon,double lat,double alt,QString type,int importance);
    inline int getUUID() const
    {
        return m_uuid;
    }
    inline double getLongitude() const
    {
        return m_lon;
    }
    inline double getLatitude() const
    {
        return m_lat;
    }
    inline double getAltitude() const
    {
        return m_alt;
    }
    inline QString getTargetType() const
    {
        return m_type;
    }
    inline int getImportance() const
    {
        return m_importance;
    }
    inline void setUUID(int id)
    {
        m_uuid = id;
    }
    inline void setLongitude(double lon)
    {
        m_lon = lon;
    }
    inline void setLatitude(double lat)
    {
        m_lat = lat;
    }
    inline void setAltitude(double alt)
    {
        m_alt = alt;
    }
    inline void setType(QString type)
    {
        m_type = type;
    }
    inline void setImportance(int importance)
    {
        m_importance = importance;
    }

private:
    int m_uuid;
    double m_lon;
    double m_lat;
    double m_alt;
    QString m_type;
    int m_importance;
};

#endif // ENEMY_H

