﻿#include "camerafrustum.h"
#include <SimpleFillSymbol.h>
#include <SimpleLineSymbol.h>
#include <GeometryEngine.h>
#include <PolygonBuilder.h>
#include <GeometryEngine.h>
#include <QVector3D>
#include <QMatrix4x4>
#include <TextSymbol.h>
using namespace Esri::ArcGISRuntime;
namespace  {
const QString HEADING = "heading";
const QString PITCH = "pitch";
const QString ROLL = "roll";


void corner(double *vz,double * vy,double * vx,double * center ,double * output,double groundheight
            ,double azimuth,double elevation)
{
    double _z = groundheight + 1 - center[2];

    double _v1[3] = {vz[0]+ vy[0] + vx[0],vz[1]+ vy[1] + vx[1],vz[2]+ vy[2] + vx[2]};

    QMatrix4x4 _elevation,_azimuth;
    _elevation.setToIdentity();
    _azimuth.setToIdentity();
    _elevation.rotate(elevation,1,0,0);
    _azimuth.rotate(-azimuth,0,0,1);
    QVector3D _qv1(_v1[0],_v1[1],_v1[2]);
    _qv1 = _elevation * _qv1;
    _qv1 = _azimuth * _qv1;
    _v1[0] = _qv1[0];_v1[1] = _qv1[1];_v1[2] = _qv1[2];


    double _scale = _z / _v1[2];

    double _v2[3] = {_scale * _v1[0],_scale * _v1[1],_scale * _v1[2]};

    output[0] = center[0] + _v2[0];
    output[1] = center[1] + _v2[1];
    output[2] = center[2] + _v2[2];
}

Polygon makePolygon(Point v1,Point v2,Point v3,Point v4)
{
    SpatialReference sr(4326);
    PolygonBuilder builder(sr);
    builder.addPoint(v1);
    builder.addPoint(v2);
    builder.addPoint(v3);
    builder.addPoint(v4);
    return builder.toGeometry();
}

}


CameraFrustum::CameraFrustum(QObject *parent,SceneQuickView * sceneview ) : QObject(parent)
  ,m_sceneView_(sceneview)
  ,m_maxCountFrustum_(12)
  ,m_countFrustum_(0)
{
    for(size_t i =0; i < m_maxCountFrustum_; i++)
    {
        SimpleLineSymbol* Outline = new SimpleLineSymbol(
                    SimpleLineSymbolStyle::Dash, QColor("#FF000008"), 1);
        SimpleFillSymbol* Symbol = new SimpleFillSymbol(
                    SimpleFillSymbolStyle::DiagonalCross, QColor("#FF008000"), Outline);

        std::vector<Graphic * > _frunstum;
        for(int j = 0 ;j < 1; j++)
        {
            Graphic * _tempGraphics1
                    = new Graphic(Geometry(),Symbol,this);
            _tempGraphics1->attributes()->insertAttribute(HEADING, 0);
            _tempGraphics1->attributes()->insertAttribute(PITCH, 0);

            m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempGraphics1);

            _frunstum.push_back(_tempGraphics1);


        }
        m_frustumGraphics_.push_back(_frunstum);
    }


}

void CameraFrustum::drawFrustum(const QB::QbImgPara *info)
{
    if(info->pitch + info->eopitch > 50 || info->pitch + info->eopitch < 0)
        return;
    if(m_UAVID_PolygonPairs_.contains(info->airID))
    {
        updateFrustum(info);
    }
    else {
        addFrustum(info);
    }
}

void CameraFrustum::updateFrustum(const QB::QbImgPara *info)
{

    std::vector<Polygon> _polygons = makeFrustumPolygon(info);
    int _index = m_UAVID_PolygonPairs_[info->airID];
    for(int i =0 ;i < 1; i++)
    {
        m_frustumGraphics_[_index][i]->setGeometry(_polygons[i]);
        m_frustumGraphics_[_index][i]->attributes()->replaceAttribute(HEADING,45);
        m_frustumGraphics_[_index][i]->attributes()->replaceAttribute(PITCH,info->eopitch + info->pitch);
    }
}

void CameraFrustum::addFrustum(const QB::QbImgPara *info)
{
    std::vector<Polygon> _polygons = makeFrustumPolygon(info);
    m_UAVID_PolygonPairs_[info->airID] = m_countFrustum_;
    int _index = m_UAVID_PolygonPairs_[info->airID];
    for(int i =0 ;i < 1; i++)
    {
        m_frustumGraphics_[_index][i]->setGeometry(_polygons[i]);
        m_frustumGraphics_[_index][i]->attributes()->replaceAttribute(HEADING,45);
        m_frustumGraphics_[_index][i]->attributes()->replaceAttribute(PITCH,info->eopitch + info->pitch);
    }
    m_countFrustum_ ++;
}





std::vector<Esri::ArcGISRuntime::Polygon> CameraFrustum::makeFrustumPolygon(const QB::QbImgPara *info)
{
    Point _planePoint =
            GeometryEngine::project(Point(info->lon,info->lat,SpatialReference::wgs84()),SpatialReference(4508));
    _planePoint = Point(_planePoint.x(),_planePoint.y(),info->alt);
    double _center[3] = {_planePoint.x(),_planePoint.y(),info->alt};
    //left_top
    double _v1[3]  = {0,0,-info->focus };
    double _v2[3] = {0,0.5 * info->sensorHeight,0};
    double _v3[3] = {-0.5 * info->sensorWidth,0,0};

    double _leftTop[3] ;

    corner(_v1,_v2,_v3,_center,_leftTop,info->gdHeight,info->yaw + info->eoaz, info->pitch + info->eopitch);
    Point _lt = GeometryEngine::project(Point(_leftTop[0],_leftTop[1],SpatialReference(4508)),SpatialReference::wgs84());
    _lt = Point(_lt.x(),_lt.y(),1);
    //left_bottom
    double _v22[3] = {0,-0.5 * info->sensorHeight,0};

    double _leftBottom[3] ;
    corner(_v1,_v22,_v3,_center,_leftBottom,info->gdHeight,info->yaw + info->eoaz, info->pitch + info->eopitch);
    Point _lb = GeometryEngine::project(Point(_leftBottom[0],_leftBottom[1],SpatialReference(4508)),SpatialReference::wgs84());
    _lb = Point(_lb.x(),_lb.y(),1);
    //righttop

    double _v33[3] = {0.5 * info->sensorWidth,0,0};
    double _rightTop[3] ;
    corner(_v1,_v2,_v33,_center,_rightTop,info->gdHeight,info->yaw + info->eoaz, info->pitch + info->eopitch);
    Point _rt = GeometryEngine::project(Point(_rightTop[0],_rightTop[1],SpatialReference(4508)),SpatialReference::wgs84());
    _rt = Point(_rt.x(),_rt.y(),1);
    //rightbottom

    double _rightBottom[3];
    corner(_v1,_v22,_v33,_center,_rightBottom,info->gdHeight,info->yaw + info->eoaz, info->pitch + info->eopitch);
    Point _rb = GeometryEngine::project(Point(_rightBottom[0],_rightBottom[1],SpatialReference(4508)),SpatialReference::wgs84());
    _rb = Point(_rb.x(),_rb.y(),1);

    std::vector<Esri::ArcGISRuntime::Polygon> _temp;
    _temp.push_back(makePolygon(_lt,_lb,_rb,_rt));


    return _temp;



}
