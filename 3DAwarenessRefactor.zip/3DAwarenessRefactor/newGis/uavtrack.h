﻿#ifndef UAVTRACK_H
#define UAVTRACK_H

#include <QObject>
#include <udplistener.h>
#include <SceneQuickView.h>
#include <QQueue>
#include"PolylineBuilder.h"

class UAVTrack : public QObject
{
    Q_OBJECT
public:
     explicit UAVTrack(QObject *parent = nullptr,Esri::ArcGISRuntime::SceneQuickView * sceneview = nullptr);
     void drawTrack(const QB::QbImgPara * info);

private:
    void updateTrack(const QB::QbImgPara * info);

    void addTrack(const QB::QbImgPara * info);

private:

    Esri::ArcGISRuntime::SceneQuickView * m_sceneView_;


    int m_maxCountTrack_;
    int m_countTrack_;
    QMap<int,size_t> m_UAVID_Track_;
    std::vector<Esri::ArcGISRuntime::Graphic*> m_TrackGraphics_;

    //队列封装画出航迹的点
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue0;
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue1;
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue2;

    //最多十二架飞机
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue3;
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue4;
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue5;
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue6;
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue7;
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue8;
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue9;
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue10;
    QQueue<Esri::ArcGISRuntime::Point> m_TrackQueue11;

    //用来构造航迹的点
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder1;
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder2;
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder0;

    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder3;
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder4;
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder5;
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder6;
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder7;
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder8;
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder9;
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder10;
    Esri::ArcGISRuntime::PolylineBuilder *polytrackBuilder11;


};

#endif // DRAWTRACK_H
