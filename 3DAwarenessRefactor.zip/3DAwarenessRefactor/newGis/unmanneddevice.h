﻿#ifndef UNMANNEDDEVICE_H
#define UNMANNEDDEVICE_H

#include <QObject>

class UnmannedDevice
{
public:
    UnmannedDevice(int uuid,double lon,double lat,double alt,QString type,float heading,float pitch,float roll);
    inline int getUUID() const{
        return m_uuid;
    }
    inline double getLongitude() const{
        return m_lon;
    }
    inline double getLatitude() const{
        return m_lat;
    }
    inline double getAltitude() const{
        return m_alt;
    }
    inline QString getType() const{
        return m_type;
    }
    inline float getHeading() const{
        return m_heading;
    }
    inline float getPitch() const{
        return m_pitch;
    }
    inline float getRoll() const{
        return m_roll;
    }
    inline void setUUID(int id)
    {
        m_uuid = id;
    }
    inline void setLongitude(double lon)
    {
        m_lon = lon;
    }
    inline void setLatitude(double lat)
    {
        m_lat = lat;
    }
    inline void setAltitude(double alt)
    {
        m_alt = alt;
    }
    inline void setType(QString type)
    {
        m_type = type;
    }
    inline void setHeading(float heading)
    {
        m_heading = heading;
    }
    inline void setPitch(float pitch){
        m_pitch = pitch;
    }
    inline void setRoll(float roll){
        m_roll = roll;
    }


signals:
private:
    int m_uuid;
    double m_lon;
    double m_lat;
    double m_alt;
    QString m_type;
    float m_heading;
    float m_pitch;
    float m_roll;
};


#endif // UNMANNEDDEVICE_H
