﻿#include "uavline.h"
#include <TextSymbol.h>
#include<QDebug>

//created by 1114
#include "SimpleLineSymbol.h"
#include "SimpleMarkerSymbol.h"
#include "GraphicsOverlay.h"
#include "PolylineBuilder.h"

//created by 1117
#include <QJsonDocument>
#include <QJsonParseError>
#include <QFile>
#include <QJsonObject>
#include <QJsonArray>

int iLine=0;
using namespace Esri::ArcGISRuntime;

UAVLine::UAVLine(QObject *parent,Esri::ArcGISRuntime::SceneQuickView * sceneview) : QObject(parent)
  ,m_maxCountLine_(12)
  ,m_countLine_(0)
  ,m_sceneView_(sceneview)
{


}

void UAVLine::drawLine(const LP::LinePoint *info)
{
    if(m_UAVID_Line_.contains(info->airID))
    {
        updateLine(info);
    }
    else {
        addLine(info);
    }
}


void UAVLine::updateLine(const LP::LinePoint *info)
{

    if(m_UAVID_Line_[info->airID]==0)
     {        
        int sum=info->m_lineQueue.size();
        m_LineQueue0.clear();
        for(int i=0;i<sum;i++)
        {
            m_LineQueue0.push_back(info->m_lineQueue[i]);
        }

        polylineBuilder0=new PolylineBuilder(SpatialReference::wgs84());
        polylineBuilder0->addPoints(m_LineQueue0);
        m_LineGraphics_[m_UAVID_Line_[info->airID]]->setGeometry(polylineBuilder0->toGeometry());
        m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_LineGraphics_[m_UAVID_Line_[info->airID]]);
     }

     if(m_UAVID_Line_[info->airID]==1)
     {
         int sum=info->m_lineQueue.size();
         m_LineQueue1.clear();
         for(int i=0;i<sum;i++)
         {
             m_LineQueue1.push_back(info->m_lineQueue[i]);
         }

         polylineBuilder1=new PolylineBuilder(SpatialReference::wgs84());
         polylineBuilder1->addPoints(m_LineQueue1);
         m_LineGraphics_[m_UAVID_Line_[info->airID]]->setGeometry(polylineBuilder1->toGeometry());
         m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_LineGraphics_[m_UAVID_Line_[info->airID]]);
     }

     if(m_UAVID_Line_[info->airID]==2)
     {
         int sum=info->m_lineQueue.size();
         m_LineQueue2.clear();
         for(int i=0;i<sum;i++)
         {
             m_LineQueue2.push_back(info->m_lineQueue[i]);
         }

         polylineBuilder2=new PolylineBuilder(SpatialReference::wgs84());
         polylineBuilder2->addPoints(m_LineQueue2);
         m_LineGraphics_[m_UAVID_Line_[info->airID]]->setGeometry(polylineBuilder2->toGeometry());
         m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(m_LineGraphics_[m_UAVID_Line_[info->airID]]);
     }
}

void UAVLine::addLine(const LP::LinePoint *info)
{
    SimpleLineSymbol* simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbolStyle::Solid, QColor("red"), 6.0f /*width*/, this);
    Graphic * _tempGraphicsLine = new Graphic(Geometry(),simpleLineSymbol,this);

    QFile loadFile("E:\\jiku\\3DAwarenessRefactor\\newGis\\LinePointJsonUDP.json");

    if(!loadFile.open(QIODevice::ReadOnly))
    {
        qDebug() << "could't open projects json";
    }

    QByteArray allData = loadFile.readAll();
    loadFile.close();

    QJsonParseError json_error;
    QJsonDocument jsonDoc(QJsonDocument::fromJson(allData, &json_error));

    if(json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "json error!";
    }

    QJsonObject rootObj = jsonDoc.object();

    //json里面最开始的头
//    QStringList keys = rootObj.keys();
//    for(int i = 0; i < keys.size(); i++)
//    {
//        qDebug() << "key" << i << " is:" << keys.at(i);
//    }

//    if(rootObj.contains("airID"))
//    {
//        QJsonArray subArray = rootObj.value("LinePoint").toArray();
//        for(int i = 0; i< subArray.size(); i++)
//        {
//            m_UAVID_Line_[info->airID] = m_countLine_;
//            m_countLine_++;
//        }
//    }

    m_UAVID_Line_[info->airID] = m_countLine_;
    m_countLine_++;

    if(m_UAVID_Line_[info->airID]==0)
    {
        int sum=info->m_lineQueue.size();
        for(int i=0;i<sum;i++)
        {
            m_LineQueue0.push_back(info->m_lineQueue[i]);
        }

        polylineBuilder0=new PolylineBuilder(SpatialReference::wgs84());
        polylineBuilder0->addPoints(m_LineQueue0);
        _tempGraphicsLine->setGeometry(polylineBuilder0->toGeometry());
        m_LineGraphics_.push_back(_tempGraphicsLine);
        m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempGraphicsLine);
    }

    if(m_UAVID_Line_[info->airID]==1)
    {
        int sum=info->m_lineQueue.size();
        for(int i=0;i<sum;i++)
        {
            m_LineQueue1.push_back(info->m_lineQueue[i]);
        }

        polylineBuilder1=new PolylineBuilder(SpatialReference::wgs84());
        polylineBuilder1->addPoints(m_LineQueue1);
        _tempGraphicsLine->setGeometry(polylineBuilder1->toGeometry());
        m_LineGraphics_.push_back(_tempGraphicsLine);
        m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempGraphicsLine);
    }

    if(m_UAVID_Line_[info->airID]==2)
    {
        int sum=info->m_lineQueue.size();
        for(int i=0;i<sum;i++)
        {
            m_LineQueue2.push_back(info->m_lineQueue[i]);
        }

        polylineBuilder2=new PolylineBuilder(SpatialReference::wgs84());
        polylineBuilder2->addPoints(m_LineQueue2);
        _tempGraphicsLine->setGeometry(polylineBuilder2->toGeometry());
        m_LineGraphics_.push_back(_tempGraphicsLine);
        m_sceneView_->graphicsOverlays()->at(1)->graphics()->append(_tempGraphicsLine);
    }



//    if(rootObj.contains("LinePoint"))
//    {
//       QJsonArray subArray = rootObj.value("LinePoint").toArray();
//       for(int i = 0; i< subArray.size(); i++)
//       {
//           //qDebug() << i<<" value is:" << subArray.at(i).toString();
//           QStringList LinePointTemp=subArray.at(i).toString().split(",");

//           int sum=info->m_lineQueue.size();
//           for(int i=0;i<sum;i++)
//           {
//               m_LineQueue0.push_back(info->m_lineQueue[i]);
//           }
//           //Point p=Point(LinePointTemp[0].toDouble(),LinePointTemp[1].toDouble(),LinePointTemp[2].toDouble());
//           //m_LineQueue0.push_back(p);
//       }
//    }
//    polylineBuilder0=new PolylineBuilder(SpatialReference::wgs84());
//    polylineBuilder0->addPoints(m_LineQueue0);
//    m_LineGraphics_.push_back(_tempGraphicsLine);

}
